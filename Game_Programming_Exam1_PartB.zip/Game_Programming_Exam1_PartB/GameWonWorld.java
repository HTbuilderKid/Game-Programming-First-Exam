import greenfoot.*; 

/**
 * GameWonWorld: a simple celebratory screen.
 */
public class GameWonWorld extends World
{
    public GameWonWorld()
    {
        super(560, 560, 1);
        GreenfootImage bg = new GreenfootImage(getWidth(), getHeight());
        bg.setColor(Color.GREEN); 
        bg.fill();
        Font font = new Font("Arial", true, false, 48); // greenfoot.Font
        bg.setFont(font);
        bg.setColor(Color.BLACK);
        bg.drawString("YOU WON!", getWidth()/2 - 140, getHeight()/2);
        setBackground(bg);
    }
}
