import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Worm: simple actor with no movement (stationary food).
 */
public class Worm extends Actor
{
    public Worm()
    {
        // Optionally set an image or scale it here
        // GreenfootImage img = getImage();
        // img.scale(20, 20);
    }

    public void act()
    {
        // Worms are stationary in this simple exercise.
    }
}
