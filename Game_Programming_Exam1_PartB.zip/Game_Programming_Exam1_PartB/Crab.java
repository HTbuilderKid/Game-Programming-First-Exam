import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Crab: player-controlled actor.
 */
public class Crab extends Actor
{
    public void act()
    {
        checkKeys();
        lookForWorm();
    }

    // method that handles key inputs (check for which keys are pressed)
    private void checkKeys()
    {
        if (Greenfoot.isKeyDown("left")) {
            turn(4);
        }
        if (Greenfoot.isKeyDown("right")) {
            turn(-4);
        }
        if (Greenfoot.isKeyDown("up")) {
            move(8);
        }
    }

    // detect and eat worms
    private void lookForWorm()
    {
        // use isTouching in if condition
        if (isTouching(Worm.class))
        {
            removeTouching(Worm.class);
            Greenfoot.playSound("slurp.wav");
            World w = getWorld();
            if (w instanceof ScoreWorld) {
                ((ScoreWorld)w).increaseScore();
            }
            // check winning condition
            if (getWorld().getObjects(Worm.class).isEmpty())
            {
                Greenfoot.playSound("fanfare.wav");
            
                // showText "You Won" and set the position at which it will be shown
                getWorld().showText("YOU WON!", getWorld().getWidth()/2, getWorld().getHeight()/2);
                Greenfoot.stop();
            }
        }
    }
}
