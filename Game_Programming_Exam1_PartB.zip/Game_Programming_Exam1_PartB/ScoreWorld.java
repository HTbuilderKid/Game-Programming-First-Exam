import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * ScoreWorld: sets up the world, adds crab, worms and a counter.
 */
public class ScoreWorld extends World
{
    private Counter counter;

    public ScoreWorld()
    {
        super(560, 560, 1);  // width, height, cell size
        counter = new Counter("Score: ");
        addObject(counter, 70, 20);
        addObject(new Crab(), getWidth()/2, getHeight()/2);
        
        // add 10 worms at random positions using a for-loop
        for (int i = 0; i < 10; i++) {
            addObject(new Worm(), Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        }
        // just to make the game a bit more fun, we're going to add 3 lobsters 
        // that spawn in at random locations. Make sure not to let them touch you!
        for (int i = 0; i < 3; i++) {
            addObject(new Lobster(), Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        }
    }

    // called by Crab when it eats a worm
    public void increaseScore()
    {
        counter.add(1);
        return;
    }
}
