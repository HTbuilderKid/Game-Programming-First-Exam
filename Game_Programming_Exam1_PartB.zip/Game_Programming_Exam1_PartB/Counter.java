import greenfoot.*; 
 

/**
 * Counter: simple on-screen counter showing a label and a value.
 */
public class Counter extends Actor
{
    private int value;
    private String label;

    public Counter()
    {
        this("");
    }

    public Counter(String prefix)
    {
        label = prefix;
        value = 0;
        updateImage();
    }

    public void increment()
    {
        value++;
        updateImage();
    }

    public void add(int amount)
    {
        value += amount;
        updateImage();
    }

    public void setValue(int v)
    {
        value = v;
        updateImage();
    }

    private void updateImage()
    {
        GreenfootImage img = new GreenfootImage(120, 30);
        img.setColor(Color.WHITE);             // greenfoot.Color
        img.fill();
        img.setColor(Color.BLACK);
        Font f = new Font("Arial", true, false, 16);  // greenfoot.Font
        img.setFont(f);;
        img.drawString(label + value, 4, 20);
        setImage(img);
    }
}
