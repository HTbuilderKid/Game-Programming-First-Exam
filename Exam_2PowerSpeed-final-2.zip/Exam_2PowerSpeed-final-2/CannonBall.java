import greenfoot.*;

public class CannonBall extends Actor
{
    private Vector2D position;
    private Vector2D velocity;

    private static final int MAX_TARGET_SPEED = 6; // cap to avoid runaway speeds

    public CannonBall(Vector2D pos, Vector2D vel)
    {
        this.position = pos;
        this.velocity = vel;
        try { setImage("cannonball.png"); } catch (Exception e) {}
    }

    public void act()
    {
        World w = getWorld();
        if (w == null) return;

        position = position.add(velocity);
        int nx = (int)Math.round(position.getX());
        int ny = (int)Math.round(position.getY());

        setLocation(nx, ny);
        
        // Target hit detection (single intersecting object)
        Actor aTarget = getOneIntersectingObject(Target.class);
        if (aTarget != null && aTarget instanceof Target)
        {
            Target t = (Target)aTarget;
            // read current speed
            int oldSpeed = t.getMoveSpeed();
            int newSpeed = oldSpeed + 5;
            if (newSpeed > MAX_TARGET_SPEED) newSpeed = MAX_TARGET_SPEED;

            // update world score/hits
            if (w instanceof MyWorld) {
                ((MyWorld)w).increaseScore(10);
                ((MyWorld)w).recordHit();
            }
            try { Greenfoot.playSound("explosion.wav"); } catch (Exception e) {}

            // remove target -> then respawn a new one with increased speed
            // IMPORTANT: remove original before respawn to avoid immediate collision with new one
            if (aTarget.getWorld() != null) aTarget.getWorld().removeObject(aTarget);
            // respawn new target with newSpeed
            if (w instanceof MyWorld) {
                ((MyWorld)w).respawnTargetWithSpeed(newSpeed);
            }
            
            // remove this cannonball
            if (getWorld() != null) getWorld().removeObject(this);
            return;
        }

        // PowerUp collision
        Actor p = getOneIntersectingObject(PowerUp.class);
        if (p != null)
        {
            if (w instanceof MyWorld) ((MyWorld)w).increaseScore(50);
            try { Greenfoot.playSound("bonus.wav"); } catch (Exception e) {}
            if (p.getWorld() != null) p.getWorld().removeObject(p);
            if (getWorld() != null) getWorld().removeObject(this);
            return;
        }

        // Miss
        if (nx < 0 || nx > w.getWidth() || ny < 0 || ny > w.getHeight()) {
            if (w instanceof MyWorld) {
                ((MyWorld)w).recordMisses();
            }
            w.removeObject(this);
            return;
        }
       
    }
}
