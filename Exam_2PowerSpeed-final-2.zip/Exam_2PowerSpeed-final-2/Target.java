import greenfoot.*;

/**
 * Target: simple horizontal movement near top; speed passed in constructor.
 */
public class Target extends Actor
{
    private int moveDirection;
    private int moveSpeed;      // positive integer >=1
  

    public Target(int speed)
    {
        try { setImage("target.png"); } catch (Exception e) {}
        if (speed < 1) speed = 1;
        moveSpeed = speed;
        // random initial direction left/right
        moveDirection = (Greenfoot.getRandomNumber(2) == 0) ? 1 : -1;
       
    }

    public void act()
    {
        // move left/right across the top
        setLocation(getX() + moveDirection * moveSpeed, getY());

        // bounce edges
        if (getX() < 40) {
            setLocation(40, getY());
            moveDirection = 1;
        } else if (getX() > getWorld().getWidth() - 40) {
            setLocation(getWorld().getWidth() - 40, getY());
            moveDirection = -1;
        }

      
    }

    public int getMoveSpeed()
    {
        return moveSpeed;
    }
}
