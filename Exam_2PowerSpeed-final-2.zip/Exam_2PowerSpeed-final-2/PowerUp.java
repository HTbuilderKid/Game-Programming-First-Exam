import greenfoot.*;

public class PowerUp extends Actor
{
    private int frame = 0;
    private int floatAmplitude = 2;

    public PowerUp()
    {
        setImage("powerup.png");
    }

    public void act()
    {
        setLocation(getX(), getY() + (int) (Math.sin(System.currentTimeMillis() / 200.0) * 2));
        //frame++;
        //int dy = (int)(Math.sin(frame * 0.1) * floatAmplitude);
        //setLocation(getX(), getY() + dy);

        // gentle blink for visibility
        if (frame % 60 == 0)
        {
            GreenfootImage img = getImage();
            int alpha = img.getTransparency();
            img.setTransparency(alpha == 255 ? 120 : 255);
            setImage(img);
        }
    }
}
