import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Cannon here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cannon2 extends Rotator
{
   
    private static int DELAY = 6;
    int reload = DELAY;
    
    /**
     * Act - do whatever the Cannon wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if(Greenfoot.isKeyDown("right"))
        {
            setRotation (getRotation() +8);
        }
        if (Greenfoot.isKeyDown("left"))
        {
            setRotation (getRotation() -8);
        }
    }    

    private void fire()
    {
        double angleRad = Math.toRadians(getRotation());
        int sx = getX();
        int sy = getY();
        Vector2D pos = new Vector2D(sx, sy);
        Vector2D vel = new Vector2D(5, 0);
        
        CannonBall ball = new CannonBall(pos, vel);
        getWorld().addObject(ball, getX(), getY());
        ball.setRotation(getRotation()-90);
        ball.move(30);
    }
}