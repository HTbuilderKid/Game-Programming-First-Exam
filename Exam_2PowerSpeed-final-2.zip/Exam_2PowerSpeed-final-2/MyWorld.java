import greenfoot.*;

public class MyWorld extends World
{
    private int score = 0;
    private int hits = 0;
    private int misses = 0;
    private int timer = 1200; // 20 seconds
    private boolean gameOver = false;

    public MyWorld()
    {
        super(800, 600, 1);
        prepare();
    }

    private void prepare()
    {
        try { setBackground("background.png"); } catch (Exception e) {}

        addObject(new Cannon(), 120, getHeight() - 80);

        // initial targets
        for (int i = 0; i < 4; i++) {
            int x = 200 + i * 120;
            int y = 80 + Greenfoot.getRandomNumber(80);
            // spawn targets with default speed 2
            addObject(new Target(2), x, y);
        }

        addObject(new PowerUp(), 450, 300);
    }

    public void act()
    {
        if (gameOver) return;
        timer--;
        showText("Score: " + score, 80, 20);
        showText("Hits: " + hits, 200, 20);
        showText("Misses: " + misses, 470, 20);
        showText("Time: " + (timer / 60) + "s", 330, 20);

        if (timer <= 0) {
            gameOver = true;
            showText("GAME OVER! Score: " + score +
                     " | Hits: " + hits +
                     " | Misses: " + misses,
                     getWidth() / 2, getHeight() / 2);
            Greenfoot.stop();
        }
    }
    
    public void recordMisses() {
        misses++;
        score -= 5; 
    }
    
    public void respawnTargetWithSpeed(int speed) {
        int x = Greenfoot.getRandomNumber(getWidth() - 160) + 80;
        int y = Greenfoot.getRandomNumber(80) + 60;
        addObject(new Target(speed), x, y);
    }
    
    public void increaseScore(int amount) { score += amount; }
    public void recordHit() { hits++; }


    /**
     * Respawn a new Target with a given speed.
     * x,y chosen randomly near top area.
    */
    
    
}
