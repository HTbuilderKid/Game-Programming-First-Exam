import greenfoot.*;

public class Cannon extends Rotator
{
    private boolean canFire = true;
    private static final int ROTATE_SPEED = 3;
    private static final double BALL_SPEED = 6.0;
    private static final int BARREL_LENGTH = 30;

    public void act()
    {
        handleRotation();
        handleFiring();
    }

    private void handleRotation()
    {
        if (Greenfoot.isKeyDown("up"))  setRotation(getRotation() - 8);//ROTATE_SPEED));
        if (Greenfoot.isKeyDown("down")) setRotation(getRotation() + 8);//ROTATE_SPEED));
    }

    private void handleFiring()
    {
        if (Greenfoot.isKeyDown("space") && canFire) {
            fire();
            canFire = false;
        }
        if (!Greenfoot.isKeyDown("space")) canFire = true;
    }

    private void fire()
    {
        double angleRad = Math.toRadians(getRotation());
        int sx = getX() + (int)Math.round(Math.cos(angleRad) * BARREL_LENGTH);
        int sy = getY() - (int)Math.round(Math.sin(angleRad) * BARREL_LENGTH);
        Vector2D pos = new Vector2D(sx, sy);
        Vector2D vel = new Vector2D(Math.cos(angleRad) * BALL_SPEED, -Math.sin(angleRad) * BALL_SPEED);
        
        CannonBall ball = new CannonBall(pos, vel);
        ball.setRotation(getRotation() + 180);
        getWorld().addObject(ball, getX(), getY());

        if (getWorld() instanceof MyWorld) ((MyWorld)getWorld()).recordHit();
        Greenfoot.playSound("fire.wav");
    }
}
