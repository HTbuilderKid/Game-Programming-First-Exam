import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

public abstract class Rotator extends Actor
{
    private double x = 0;
    private double y = 0;
    public double getExactX()
    {
        return x;
    }
    
    public double getExactY()
    {
        return y;
    }
    
    public void setLocation(double x, double y) 
    {
        this.x = x;
        this.y = y;
        super.setLocation((int) x, (int) y);
    }
    
    public void setLocation(int x, int y) 
    {
        setLocation((double) x, (double) y);
    }
    
    public double getRotation(double x, double y)
    {
        double xDistance = getExactX()-x;
        double yDistance = getExactY()-y;
        double angle = Math.toDegrees(Math.atan2(yDistance, xDistance))+180;
        
        return angle;
    }

    public void setRotation(double degrees, double x, double y)
    {
        degrees = ((degrees+180) % 360)-180;
        if(Math.abs(degrees)==180) {
            setRotation(179.9, x, y);
            return;
        } else {
            double xDistance = getExactX()-x;
            double yDistance = getExactY()-y;
            double distance = Math.sqrt((xDistance*xDistance + yDistance*yDistance));
            setLocation(x-distance, y);
            double theta = (180-degrees)/2;
            double c = (distance*sin(degrees))/(sin(theta)); 
            double dx = c*cos(theta);
            double dy = c*sin(theta);
            
            setLocation(getExactX()+dx, getExactY()-dy);
        }
    }
    
    private double sin(double a)
    {
        return Math.sin(Math.toRadians(a));
    }
    
    private double cos(double a)
    {
        return Math.cos(Math.toRadians(a));
    }
    
    private double tan(double a)
    {
        return Math.tan(Math.toRadians(a));
    }
}