public class Vector2D
{
    private double x, y;

    public Vector2D(double x, double y) { this.x = x; this.y = y; }

    public double getX() { return x; }
    public double getY() { return y; }

    public Vector2D add(Vector2D v)
    {
        return new Vector2D(this.x + v.x, this.y + v.y);
    }

    public String toString() { return "(" + x + "," + y + ")"; }
}
